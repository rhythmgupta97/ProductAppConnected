﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ProjectManagementApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);

        SqlCommand command = new SqlCommand();
        public MainWindow()
        {
            InitializeComponent();
        }

      
        private void AddProduct(object sender, RoutedEventArgs e)
        {
            
            try
            {
                connection.Open();
            
                string ProductName = txtProductName.Text;
                float ProductPrice = float.Parse(txtPrice.Text);
                int ProductQuantity = int.Parse(txtQuantity.Text);

                command.CommandText = "INSERT INTO Product_46022923 VALUES ('" + ProductName + "', " + ProductPrice + "," + ProductQuantity +")";
                command.Connection = connection;
                int numberOfRowsAdded = command.ExecuteNonQuery();
                if (numberOfRowsAdded == 1)
                {
                    MessageBox.Show("Product Added Successfully");
                }
                else
                {
                    MessageBox.Show("Something went wrong");
                }
            }
            catch(SqlException exception)
            {
                MessageBox.Show("Exception Ocurred. Details are:" + exception.Message);
            }
            finally
            {
                
                connection.Close();
            }
            LoadGrid();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }
        private void LoadGrid()
        {
            try
            {
                connection.Open();
                command.CommandText = "SELECT * FROM Product_46022923";
                command.Connection = connection;
                SqlDataReader reader = command.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                DGrid.DataContext = table;
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Ocurred. Details are:" + exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    command.Dispose();
                }
                connection.Close();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();
                command.CommandText = "SELECT * FROM Product_46022923 WHERE ProductId="+int.Parse(txtProductId.Text);
                command.Connection = connection;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    txtProductName.Text = reader["ProductName"].ToString();
                    txtPrice.Text = reader["ProductPrice"].ToString();
                    txtProductId.Text = reader["ProductId"].ToString();
                    txtQuantity.Text = reader["ProductQuantity"].ToString();
                }
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Ocurred. Details are:" + exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    command.Dispose();
                }
                connection.Close();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            txtProductId.Text = "";
            txtProductName.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";
        }

        private void DeleteProduct(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();
                command.CommandText = "DELETE FROM Product_46022923 WHERE ProductId=" + int.Parse(txtProductId.Text);
                command.Connection = connection;
                int numberOfRowDeleted = command.ExecuteNonQuery();

                if (numberOfRowDeleted>0)
                {
                    MessageBox.Show("Deleted Successfully!");
                }
                else
                {
                    MessageBox.Show("Something is wrong!");
                }
             

            }

            catch (SqlException exception)
            {
                MessageBox.Show("Exception Ocurred. Details are:" + exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    command.Dispose();
                }
                connection.Close();
            }
            LoadGrid();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "UPDATE Product_46022923 SET ProductName= '" + txtProductName.Text + "' , productPrice=" + int.Parse(txtPrice.Text) + " , productQuantity=" + int.Parse(txtQuantity.Text) + " where ProductId = " + int.Parse(txtProductId.Text) + " ";
                try
                {
                    int startus = command.ExecuteNonQuery();
                    if (startus > 0)
                    {
                        MessageBox.Show("Updated..");
                    }
                    else
                    {
                        MessageBox.Show("Error in adding the products:");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" Not Updated:" + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Ocurred. Details are:" + exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.Dispose();
                }
                connection.Close();
            }
            LoadGrid();

        }
        //private void CountProduct()
        //{
        //    try
        //    {
        //        connection.Open();
        //        command.CommandText = "SELECT COUNT(ProductId) FROM Product_46022923";
        //        command.Connection = connection;
        //        SqlDataReader count = command.ExecuteScalar().ToString;

        //    }
        //    catch (SqlException exception)
        //    {
        //        MessageBox.Show("Exception Ocurred. Details are:" + exception.Message);
        //    }
        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            command.Dispose();
        //        }
        //        connection.Close();
        //    }


    }
}
